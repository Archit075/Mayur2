﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineGroup.data;
using OnlineGroup.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OnlineGroup.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DiscussionController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        /*public DiscussionController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Discussion>>> GetDiscussions()
        {
            return await _context.Discussions.ToListAsync();
        }
        [HttpPost]
        public async Task<ActionResult<Discussion>> CreateDiscussion(Discussion discussion)
        {
            _context.Discussions.Add(discussion);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetDiscussions), new { id = discussion.Id }, discussion);
        }*/
    }
}
