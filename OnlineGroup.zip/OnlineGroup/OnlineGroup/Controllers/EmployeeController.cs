﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineGroup.Models;

namespace OnlineGroup.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        [Authorize]
        [HttpGet]
        [Route("GetData")]
        public string GetData()
        {
            return "";
        }

        [HttpGet]
        [Route("Details")]
        public string Details()
        {
            return "";
        }

        [Authorize]
        [HttpPost]

        public string AddUser(Student user)
        {
            return "user" + user.Email;
        }
    }
}
