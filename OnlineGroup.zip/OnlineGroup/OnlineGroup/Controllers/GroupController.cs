﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineGroup.data;
using OnlineGroup.Models;

namespace OnlineGroup.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public GroupController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: api/group
        /*[HttpPost]
        public ActionResult<Group> CreateGroup(Group group)
        {
            try
            {
                group.CreatedAt = DateTime.UtcNow; // Set creation timestamp
                _context.Groups.Add(group);
                _context.SaveChanges();

                return Ok(group);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }*/
        [HttpPost]
        public ActionResult<Group> CreateGroup(Group group)
        {
            try
            {
                // Ensure the provided AdminId corresponds to an existing admin
                var admin = _context.studentModels.FirstOrDefault(s => s.Id == group.AdminId);
                if (admin == null)
                {
                    return NotFound("Admin not found");
                }

                // Set creation timestamp
                group.CreatedAt = DateTime.UtcNow;

                // Assign the retrieved admin object to the group's Admin property
                group.Admin = admin;

                _context.Groups.Add(group);
                _context.SaveChanges();

                return Ok(group);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET: api/group
        [HttpGet]
        public ActionResult<IEnumerable<Group>> GetGroups()
        {
            try
            {
                var groups = _context.Groups.ToList();
                return Ok(groups);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // DELETE: api/group/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGroup(int id)
        {
            try
            {
                var group = await _context.Groups.FindAsync(id);
                if (group == null)
                {
                    return NotFound();
                }

                _context.Groups.Remove(group);
                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET: api/group/{groupId}/members
        [HttpGet("{groupId}/members")]
        public ActionResult<IEnumerable<Student>> GetGroupMembers(int groupId)
        {
            try
            {
                var group = _context.Groups.FirstOrDefault(g => g.Id == groupId);
                if (group == null)
                {
                    return NotFound("Group not found");
                }

                // Assuming you have a navigation property named "Students" in your Group model
                var members = group.Students.ToList();
                return Ok(members);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
