﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineGroup.data;
using OnlineGroup.Models;

namespace OnlineGroup.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentLoginController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public StudentLoginController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/StudentLoginModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StudentLoginModel>>> GetstudentModels()
        {
            return await _context.studentModels.ToListAsync();
        }

        // GET: api/StudentLoginModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<StudentLoginModel>> GetStudentLoginModel(int id)
        {
            var studentLoginModel = await _context.studentModels.FindAsync(id);

            if (studentLoginModel == null)
            {
                return NotFound();
            }

            return studentLoginModel;
        }

        // PUT: api/StudentLoginModels/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutStudentLoginModel(int id, StudentLoginModel studentLoginModel)
        {
            if (id != studentLoginModel.Id)
            {
                return BadRequest();
            }

            _context.Entry(studentLoginModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentLoginModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/StudentLoginModels
        [HttpPost]
        public async Task<ActionResult<StudentLoginModel>> PostStudentLoginModel(StudentLoginModel studentLoginModel)
        {
            _context.studentModels.Add(studentLoginModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetStudentLoginModel", new { id = studentLoginModel.Id }, studentLoginModel);
        }

        // DELETE: api/StudentLoginModels/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudentLoginModel(int id)
        {
            var studentLoginModel = await _context.studentModels.FindAsync(id);
            if (studentLoginModel == null)
            {
                return NotFound();
            }

            _context.studentModels.Remove(studentLoginModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPost("join/{groupId}")]
        public async Task<IActionResult> JoinGroup(int groupId, StudentLoginModel studentData)
        {
            try
            {
                // Get the student's data from the request body
                if (studentData == null)
                {
                    return BadRequest("Student data is required");
                }

                // Find the group by its ID
                var group = await _context.Groups.FindAsync(groupId);
                if (group == null)
                {
                    return NotFound("Group not found");
                }

                // Create a new Student entity
                var newStudent = new Student
                {
                    Name = studentData.Name,
                    Email = studentData.Email,
                    Password = studentData.Password,
                    GroupId = groupId
                };

                // Add the new student to the Students table
                _context.Students.Add(newStudent);

                // Add the student to the group's Students collection
                if (group.Students == null)
                {
                    group.Students = new System.Collections.Generic.List<Student>();
                }
                group.Students.Add(newStudent);

                // Save changes to the database
                await _context.SaveChangesAsync();

                return Ok("Student joined the group successfully");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        private bool StudentLoginModelExists(int id)
        {
            return _context.studentModels.Any(e => e.Id == id);
        }

    }
}
