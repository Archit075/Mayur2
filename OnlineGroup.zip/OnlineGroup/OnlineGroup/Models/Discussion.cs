﻿namespace OnlineGroup.Models
{
    public class Discussion
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
