﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineGroup.Models
{
    public class Group
    {
        [Key]
        public int Id { get; set; }

        
        public string? GroupName { get; set; }

        
        public string? Description { get; set; }

        
        public string? Subject { get; set; }

        [Required]
        public PrivacySetting PrivacySetting { get; set; }= PrivacySetting.Public;

        public int AdminId { get; set; }

        [ForeignKey("AdminId")]
        public StudentLoginModel? Admin { get; set; }

        public DateTime CreatedAt { get; set; }

        public ICollection<Student>? Students { get; set; }

        public Group()
        {
            CreatedAt = DateTime.UtcNow; // Initialize CreatedAt with the current UTC time
        }
    }

    public enum PrivacySetting
    {
        Public,
        Private,
        InviteOnly
    }
}

