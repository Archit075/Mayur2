﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace OnlineGroup.Models
{
    public class GroupParticipant
    {
        [Key]
        public int ParticipantId { get; set; }

        // Foreign key properties
        public int GroupId { get; set; }
        public int StudentId { get; set; }

        // Navigation properties
        [ForeignKey(nameof(GroupId))]
        public Group Group { get; set; }

        [ForeignKey(nameof(StudentId))]
        public Student Student { get; set; }
    }
}
