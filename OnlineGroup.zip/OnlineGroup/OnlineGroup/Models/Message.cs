﻿namespace OnlineGroup.Models
{
    public class Message
    {
        public int Id { get; set; }
        public int DiscussionId { get; set; }
        public string Content { get; set; }
    }
}
