﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace OnlineGroup.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public StudentRoleTemp Role { get; set; }= StudentRoleTemp.Participant; // Added property to represent the role of the student

        //   public ICollection<GroupParticipant> GroupParticipants { get; set; }
        public int? GroupId { get; set; }

        [JsonIgnore]
        [ForeignKey("GroupId")]
        public Group? Group { get; set; }
    }


    // Enum to represent user roles
    public enum StudentRoleTemp
    {
        Participant,
        Admin
    }


}

