﻿using System.ComponentModel.DataAnnotations;

namespace OnlineGroup.Models
{
    public class StudentLoginModel
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public StudentRole Role { get; set; } = StudentRole.Participant;
    }
    public enum StudentRole
    {
        Participant,
        Admin
    }
}
