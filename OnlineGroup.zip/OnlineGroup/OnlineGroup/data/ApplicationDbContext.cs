﻿using Microsoft.EntityFrameworkCore;
using OnlineGroup.Models;

namespace OnlineGroup.data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
        {
        }

        public DbSet<Group> Groups { get; set; }
        public DbSet<Student> Students { get; set; }

        /*public DbSet<Admin> Admins { get; set; }*/

        public DbSet<StudentLoginModel> studentModels { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


            modelBuilder.Entity<Group>()
                .HasOne(g => g.Admin)
                .WithMany()
                .HasForeignKey(g => g.AdminId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Group>()
                .HasOne(g => g.Admin)
                .WithMany()
                .HasForeignKey(g => g.AdminId);

        }
    }
}
